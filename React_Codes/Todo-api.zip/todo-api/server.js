const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

const todods = [
    { id: 1, description: 'Feed dog', assigned: 'Eric' },
    { id: 2, description: 'Get a haircut', assigned: 'Eric' },
];

app.get('/api/todos', (req, res) => {
  res.json(todos);
});

app.listen(8080, () => console.log('API running on http://localhost:8080'));